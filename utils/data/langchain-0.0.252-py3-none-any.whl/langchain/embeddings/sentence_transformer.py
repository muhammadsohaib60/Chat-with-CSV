"""HuggingFace sentence_transformer embedding models."""
from langchain.embeddings.huggingface import HuggingFaceEmbeddings

SentenceTransformerEmbeddings = HuggingFaceEmbeddings
